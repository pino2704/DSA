public class Test {
    public static void main(String[] args) {
        AVL bst = new AVL();
        bst.insert(18);
        bst.insert(24);
        bst.insert(31);
        bst.insert(12);
        bst.insert(15);
        bst.insert(39);
        bst.insert(45);
        bst.insert(35);
        bst.deleteSuccessor(18);
        bst.deleteSuccessor(15);

        bst.NLR();
        // System.out.println();

        // System.out.println(bst.deleteSuccessor(7));

        // System.out.println(bst.sumEvenKeysAtLeaves());

        // bst.bfs();

    }
}
